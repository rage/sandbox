
import java.util.Scanner;

public class YmpyranKehanPituus {
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);

        // Toteuta ohjelmasi tähän. 
        System.out.print("Anna ympyrän säde: ");
        int ympyranSade = Integer.parseInt(lukija.nextLine());

        System.out.println(""); // tyhjä rivi
        System.out.println("Ympyrän kehä: " + (2 * Math.PI * ympyranSade));
    }
}
